/*
 * DR_inicializacion.h
 *
 *  Created on: 5 de set. de 2018
 *      Author: Marian
 */

#ifndef DR_INICIALIZACION_H_
#define DR_INICIALIZACION_H_

void Inicializacion(void);

#define LED_STICK PORT0, 22

#endif /* DR_INICIALIZACION_H_ */
